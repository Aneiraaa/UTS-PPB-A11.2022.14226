package com.example.uts_a11202214226

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
