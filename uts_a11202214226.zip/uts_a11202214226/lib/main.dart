import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Catatan Transaksi Toko Komputer',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: TransactionPage(),
    );
  }
}

class TransactionPage extends StatefulWidget {
  @override
  _TransactionPageState createState() => _TransactionPageState();
}

class _TransactionPageState extends State<TransactionPage> {
  final List<Map<String, dynamic>> items = [
    {
      'name': 'Laptop',
      'price': 15000000,
      'quantity': 0,
      'controller': TextEditingController()
    },
    {
      'name': 'Mouse',
      'price': 150000,
      'quantity': 0,
      'controller': TextEditingController()
    },
    {
      'name': 'Keyboard',
      'price': 300000,
      'quantity': 0,
      'controller': TextEditingController()
    },
  ];

  int totalBayar = 0;
  List<String> struk = [];

  void resetTransaction() {
    setState(() {
      for (var item in items) {
        item['quantity'] = 0;
        item['controller'].text = '0'; // Mengatur TextField kembali ke 0
      }
      struk.clear();
      totalBayar = 0;
    });
  }

  void cetakStruk() {
    setState(() {
      struk.clear();
      totalBayar = 0;
      for (var item in items) {
        int subtotal = item['quantity'] * item['price'];
        if (item['quantity'] > 0) {
          struk.add('${item['name']} x ${item['quantity']} = Rp $subtotal');
          totalBayar += subtotal;
        }
      }
    });
  }

  @override
  void dispose() {
    // Membersihkan semua controller saat halaman ditutup
    for (var item in items) {
      item['controller'].dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Catatan Transaksi Toko Komputer'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final item = items[index];
                  return Container(
                    margin: const EdgeInsets.symmetric(vertical: 4.0),
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: ListTile(
                      title: Text(
                        item['name'],
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text('Rp ${item['price']}'),
                      trailing: SizedBox(
                        width: 60,
                        child: TextField(
                          controller:
                              item['controller'], // Menggunakan controller
                          keyboardType: TextInputType.number,
                          onChanged: (value) {
                            setState(() {
                              // Validasi untuk memastikan hanya angka yang bisa diterima
                              int? quantity = int.tryParse(value);
                              if (quantity == null || quantity < 0) {
                                item['quantity'] = 0;
                              } else {
                                item['quantity'] = quantity;
                              }
                            });
                          },
                          decoration: InputDecoration(
                            border: OutlineInputBorder(),
                            hintText: '0',
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            Divider(),
            Text(
              'Struk Transaksi',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: struk.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(struk[index]),
                  );
                },
              ),
            ),
            Divider(),
            Container(
              padding: EdgeInsets.all(8.0),
              color: Colors.blue[100],
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Total Bayar:',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'Rp $totalBayar',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: resetTransaction,
                  child: Text('Reset'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                ),
                ElevatedButton(
                  onPressed: cetakStruk,
                  child: Text('Cetak Struk'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
